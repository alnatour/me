<template>
  <!-- services -->
  <div>
    <Breadcrumb src="../src/assets/images/banner/pexels-fauxels-3184325.jpg">
        <template v-slot:heading>Leistungen</template>
    </Breadcrumb>


    <section class="section">
      <div class="container">

        <!-- service item 1 -->
        <div class="row" data-aos="fade-up" data-aos-duration="1500">
          <div class="col-lg-5 align-self-center order-2 order-lg-1 mb-md-50" data-aos="fade-right"
            data-aos-duration="1500">
            <img class="img-fluid w-50 rounded" src="@/assets/images/icons/webprogrammierung-und-design.png" alt="service-image">
          </div>
          <div class="col-lg-7 order-1 order-lg-2" data-aos="fade-left" data-aos-duration="1500">
            <h3 class="section-title section-title-border-half">Webprogrammierung und Design</h3>
            <h5>Gestaltung und Entwicklung von Websites</h5>
            <p>
              Wir bieten alle auf die Gestaltung und Entwicklung von Websites spezialisierten Dienstleistungen mit
              höchsten
              Qualitätsstandards an.
            </p>
            <p>
              Gestaltung und Programmierung aller Arten von Websites (persönlich - gewerblich - Firmen - E-Commerce -
              Plattformen - spezialisierte Systeme - ...)
              und deren Kompatibilität mit allen Bildschirmen
            </p>
          </div>
        </div>
        <!-- /service item 1 -->

        <div class="mt-4 mb-4" style="height: 75px; width:100%;"></div>

        <!-- service item 2 -->
        <div class="row" data-aos="fade-up" data-aos-duration="1500">
          <div class="col-lg-5 align-self-center order-1 order-lg-2 mb-md-50" data-aos="fade-left"
            data-aos-duration="1500">
            <img class="img-fluid w-50 rounded " src="@/assets/images/icons/suchmaschinenoptimierung-SEO.png" alt="service-image">
          </div>
          <div class="col-lg-7 order-2 order-lg-1" data-aos="fade-right" data-aos-duration="1500">
            <h3 class="section-title section-title-border-half">Suchmaschinenoptimierung SEO</h3>
            <h5>Das Ranking der Website in der Suchmaschin</h5>
            <p>
              Verbessern Sie die Suchmaschinen und erhöhen Sie das Ranking der Website in der Suchmaschine,
              sodass sie auf der ersten Seite der Google-Suchmaschine steht
            </p>
          </div>
        </div>
        <!-- /service item 2 -->

        <div class="mt-4 mb-4" style="height: 75px; width:100%;"></div>

        <!-- service item 3 -->
        <div class="row" data-aos="fade-up" data-aos-duration="1500">
          <div class="col-lg-5 align-self-center order-2 order-lg-1 mb-md-50" data-aos="fade-right"
            data-aos-duration="1500">
            <img class="img-fluid w-100 rounded " src="@/assets/images/work/future-2.jpg" alt="service-image">
          </div>
          <div class="col-lg-7 order-1 order-lg-2" data-aos="fade-left" data-aos-duration="1500">
            <h3 class="section-title section-title-border-half">E-Commerce-Entwicklung</h3>
            <h5>elektronischer Shops</h5>
            <p>
              Entwicklung elektronischer Shops und Verknüpfung mit allen Diensten, die der Shop benötigt (Verknüpfung
              des Zahlungsgateways - Anbindung des Versandtors - ...) sowie Gestaltung, Entwicklung, Änderung und
              Lokalisierung von WordPress-Sites
            </p>
          </div>
        </div>
        <!-- /service item 3 -->
        <div class="mt-4 mb-4" style="height: 75px; width:100%;"></div>

        <!-- service item 4 -->
        <div class="row" data-aos="fade-up" data-aos-duration="1500">
          <div class="col-lg-5 align-self-center order-1 order-lg-2 mb-md-50" data-aos="fade-left"
            data-aos-duration="1500">
            <img class="img-fluid w-100 rounded " src="@/assets/images/work/future-3.jpg" alt="service-image">
          </div>
          <div class="col-lg-7 order-2 order-lg-1" data-aos="fade-right" data-aos-duration="1500">
            <h3 class="section-title section-title-border-half">Softwaretechnische Beratung</h3>
            <h5>Beratung, Planung & Service</h5>
            <p>
              Basierend auf den Zielen Ihrer neuen Webseite, erarbeiten wir ein individuelles Konzept für Sie und
              entwickeln dieses gemeinsam laufend weiter.
              <br>
              Fachliche technische Beratung im Bereich Software, beginnend bei Ihnen, beginnend mit der Auswahl der
              Programmiersprache, über die Auswahl der ausführenden Agentur, bis hin zum Erhalt der vollständigen Arbeit
              und dem Start des Projekts. Für weitere Details kontaktieren Sie uns
            </p>
          </div>
        </div>
        <!-- /service item 4 -->
      </div>
    </section>


    <section class="fun-facts overlay-dark section-sm" style="background-image: url(images/background/cta.jpg)">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
            <div class="
                d-flex
                flex-sm-row flex-column
                justify-content-lg-center
                align-items-center
                text-center text-sm-left
              ">
              <i class="round-icon ti-server mr-sm-3 mr-0 mb-3 mb-sm-0"></i>
              <div class="text-center text-sm-left">
                <h3 class="count text-white mb-0" data-count="95">95</h3>
                <p class="text-white mb-0">Projekte erledigt</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
            <div class="
                d-flex
                flex-sm-row flex-column
                justify-content-lg-center
                align-items-center
                text-center text-sm-left
              ">
              <i class="round-icon ti-face-smile mr-sm-3 mr-0 mb-3 mb-sm-0"></i>
              <div class="text-center text-sm-left">
                <h3 class="count text-white mb-0" data-count="75">75</h3>
                <p class="text-white mb-0">Zufriedene Kunden</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
            <div class="
                d-flex
                flex-sm-row flex-column
                justify-content-lg-center
                align-items-center
                text-center text-sm-left
              ">
              <i class="round-icon ti-thumb-up mr-sm-3 mr-0 mb-3 mb-sm-0"></i>
              <div class="text-center text-sm-left">
                <h3 class="count text-white mb-0" data-count="580">580</h3>
                <p class="text-white mb-0">Tasse Kaffee</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
            <div class="
                d-flex
                flex-sm-row flex-column
                justify-content-lg-center
                align-items-center
                text-center text-sm-left
              ">
              <i class="round-icon ti-cup mr-sm-3 mr-0 mb-3 mb-sm-0"></i>
              <div class="text-center text-sm-left">
                <h3 class="count text-white mb-0" data-count="5">5</h3>
                <p class="text-white mb-0">Auszeichnungen gewinnen</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--  work process  -->
    <section class="section position-relative pb-xl-200-lg-100">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12 text-center">
            <h5 class="section-title-sm">Wissen über</h5>
            <h3 class="section-title section-title-border mb-xl-150-lg-100">
              Wie wir das machen
            </h3>
          </div>
          <!-- process step -->
          <div class="col-lg-4 col-sm-6 mb-md-50">
            <div class="
                process-item
                py-xl-4
                pl-xl-5
                pt-5
                px-4
                rounded
                border
                position-relative
              ">
              <div class="process-item-number">1</div>
              <h5 class="text-primary">Konsultation</h5>
              <p>
                Lassen Sie uns bei Ihren Design- und Marketinganforderungen helfen, damit Sie sich auf Ihr Geschäft
                konzentrieren können,
                während wir uns auf die Erstellung und Verwaltung Ihrer Website konzentrieren.
              </p>
            </div>
          </div>
          <!-- process step -->
          <div class="col-lg-4 col-sm-6 mb-md-50">
            <div class="
                process-item
                py-xl-4
                pl-xl-5
                pt-5
                px-4
                rounded
                border
                position-relative
              ">
              <div class="process-item-number">2</div>
              <h5 class="text-primary">Kampagne</h5>
              <p>
                Im Gegensatz zu Print-Kampagnen kann der Erfolg einer Online-Werbekampagne genau gemessen werden. Das
                ist der wichtigste Vorteil. Für die Erfolgsmessung gibt es Google-Analyse- und weitere SEO-Tools, die
                den Traffic der Website analysieren.
              </p>
            </div>
          </div>
          <!-- process step -->
          <div class="col-lg-4 col-sm-6 mb-md-50">
            <div class="
                process-item
                py-xl-4
                pl-xl-5
                pt-5
                px-4
                rounded
                border
                position-relative
              ">
              <div class="process-item-number">3</div>
              <h5 class="text-primary">Progress</h5>
              <p>
                Ist die Webseite effektiv? Werden Inhalte effizient vermittelt, der Download gestartet und Formulare
                ausgefüllt?
                Wir messen die definierten Ziele ganz genau und kennen alle Parameter.
              </p>
            </div>
          </div>
        </div>
      </div>
      <!--
     <img class="arrow-top" src="@/assets/images/arrow-top.png" alt="" />
     <img class="arrow-bottom" src="@/assets/images/arrow-bottom.png" alt="" />
      -->
   </section>
   <!--  /work process  -->

    
    <!-- Die Steps zu Ihrer Corporate Website -->
    <section class="section">
      <div class="container text-center">
        <h2>Die Steps zu Ihrer Corporate Website</h2>
        <p>
          Wir begleiten Ihr digitales Projekt und setzen es in drei Hauptphasen um – Strategie und Beratung, Umsetzung
          Ihres Projekts und laufende Wartung und Instandhaltung. Unser professionelles Team steht Ihnen zur Verfügung.
        </p>

        <!-- Steps 1  -->
        <div class="row" data-aos="fade-up" data-aos-duration="1500">
          <div class="col-lg-7 order-2 order-lg-1 mx-auto text-center">
            <div class="d-flex justify-content-center">
              <img src="@/assets/images/icons/softwaretechnische-beratung-2.png" class="img-fluid"
                alt="Webprogrammierung und Design" />
            </div>
            <h3 class="section-title">
              1. Strategie & Beratung für Ihre Website
            </h3>
            <p>
              In einem gemeinsamen Launch-Workshop mit Ihnen evaluieren wir Ihre Anforderungen an Ihre Business-Website,
              um die perfekte Lösung für Ihre Business-Website zu finden. Deshalb können wir das perfekte System für
              Ihre Bedürfnisse auswählen und damit eine personalisierte Website für Sie erstellen.
            </p>
            <hr />
          </div>
        </div>
        <!-- /Steps 1  -->

        <!-- Steps 2  -->
        <div class="row" data-aos="fade-up-left" data-aos-duration="1500">
          <div class="col-lg-7 order-2 order-lg-1 mx-auto text-center">
            <div class="d-flex justify-content-center">
              <img src="@/assets/images/icons/webprogrammierung-und-design.png" class="img-fluid"
                alt="Webprogrammierung und Design" />
            </div>
            <h3 class="section-title">2. Umsetzung</h3>
            <p>
              Unsere zertifizierten Entwicklungsteams aus den Bereichen TYPO3 und WordPress setzen Ihre
              digitalen Projekte mit schnellem Projektmanagement nahtlos um. Agiles Projektmanagement zielt auf einen
              effizienten Einsatz von Aufwand und Ressourcen aus konzeptioneller und technischer Sicht.
            </p>
            <hr />
          </div>
        </div>
        <!-- /Steps 2  -->

        <!-- Steps 3  -->
        <div class="row" data-aos="fade-up-right" data-aos-duration="1500">
          <div class="col-lg-7 order-2 order-lg-1 mx-auto text-center">
            <div class="d-flex justify-content-center">
              <img src="@/assets/images/icons/webprogrammierung-und-design.png" class="img-fluid"
                alt="Webprogrammierung und Design" />
            </div>
            <h3 class="section-title">3. Wartung & Optimierung</h3>
            <p>
              Gemeinsam mit Ihnen werten wir kontinuierlich den Status Ihrer Website aus, um Funktionen rechtzeitig zu
              identifizieren und zu implementieren. Darüber hinaus führen wir ständige Aktualisierungen und
              Wartungsarbeiten durch, um sicherzustellen, dass Besucher auf Ihrer Website immer ein sicheres Erlebnis
              haben und Ihr Unternehmen wettbewerbsfähig bleibt, und wir beheben potenzielle Sicherheitslücken auf Ihrer
              Website, sobald wir sie entdecken.
            </p>
            <hr />
          </div>
        </div>
        <!-- /Steps 3  -->
      </div>
    </section>
    <!-- /Die Steps zu Ihrer Corporate Website -->

  </div>
  <!-- /service -->
</template>

<script>

export default {

  props: ['src'],

  components: {
  },

  setup() {
    return {};
  },
};
</script>

<style>
</style>
