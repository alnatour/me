<template>
  <div>
    <Breadcrumb>
      <template v-slot:heading>Empty Page</template>
    </Breadcrumb>

  </div>
</template>

<script>

export default {

  components: {
  },
  
  setup() {
    return {};
  },
};
</script>

<style>
</style>
