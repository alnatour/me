<template>
  <div>
    <Breadcrumb>
      <template v-slot:heading>Our Team</template>
    </Breadcrumb>


    <section class="section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h2 class="mb-2">Our Awesome Team</h2>
                    <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        <br> tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.</p>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-1.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Phillip Wilson</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-2.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Steve Woah</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-3.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Andrew Givson</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-4.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Joseph Pullin</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-5.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Alex Cagar</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4">
                    <div class="card text-center">
                        <a href="team-single.html">
                            <img class="card-img-top" src="@/assets/images/team/team-page-6.jpg" alt="team-member">
                        </a>
                        <div class="card-body card-body-2 pb-0 px-4">
                            <h5 class="card-title">Alisha Mayar</h5>
                            <h6 class="text-color mb-30">CEO</h6>
                            <ul class="list-inline border-top d-inline-block">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block p-3">
                                        <i class="ti-google"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /team -->
    <!-- cta -->
    <section class="cta overlay-primary py-50" style="background-image: url(images/background/cta.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 text-center text-lg-left mb-4 mb-lg-0">
                    <h3 class="text-white">Join The People Behind Our Succes</h3>
                    <p class="text-white mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                </div>
                <div class="col-lg-3 text-lg-right text-center align-self-center">
                    <a href="contact.html" class="btn btn-light">APPLY NOW</a>
                </div>
            </div>
        </div>
    </section>
    <!-- /cta -->

    <!-- team 2 -->
    <section class="section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h2 class="mb-2">Our Management Team</h2>
                    <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod <br> tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.</p>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                    <div class="card text-center p-3">
                        <img class="card-img-top rounded" src="@/assets/images/team/team-1.jpg" alt="team member image">
                        <div class="card-body pb-0">
                            <a href="team-single.html" class="card-title h4 font-primary text-dark">Amanda Richards</a>
                            <h6 class="text-color">Accounts</h6>
                            <p class="card-text border-bottom pb-3">Lorem ipsum dolor amet consectur adipsicing elit sed eiusm tempor incididunt labore dolore magna aliqua enim minim.</p>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-skype"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                    <div class="card text-center p-3">
                        <img class="card-img-top rounded" src="@/assets/images/team/team-2.jpg" alt="team member image">
                        <div class="card-body pb-0">
                            <a href="team-single.html" class="card-title h4 font-primary text-dark">Hermione Grenger</a>
                            <h6 class="text-color">Accounts</h6>
                            <p class="card-text border-bottom pb-3">Lorem ipsum dolor amet consectur adipsicing elit sed eiusm tempor incididunt labore dolore magna aliqua enim minim.</p>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-skype"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- team member -->
                <div class="col-lg-4 col-sm-6">
                    <div class="card text-center p-3">
                        <img class="card-img-top rounded" src="@/assets/images/team/team-3.jpg" alt="team member image">
                        <div class="card-body pb-0">
                            <a href="team-single.html" class="card-title h4 font-primary text-dark">Alex Pitt</a>
                            <h6 class="text-color">Accounts</h6>
                            <p class="card-text border-bottom pb-3">Lorem ipsum dolor amet consectur adipsicing elit sed eiusm tempor incididunt labore dolore magna aliqua enim minim.</p>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#" class="text-color d-inline-block py-1 px-2 px-xl-3">
                                        <i class="ti-skype"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- / eam 2 -->
  </div>
</template>

<script>

export default {

  components: {
  },

  setup() {
    return {};
  },

};
</script>

<style>
</style>
