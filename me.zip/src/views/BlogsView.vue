<template>
  <div>
    <Breadcrumb>
      <template v-slot:heading>Blogs</template>
    </Breadcrumb>

    <!-- *** Blog Section Start *** -->
    <section class="bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 py-100">
                    <!-- Blog Post -->
                    <article class="bg-white rounded mb-40">
                        <!-- Post Thumbnail -->
                            <a href="/blog-single.html">
                                <img class="img-fluid w-100 rounded-top" src="blogs-Dateien/blog-big-thumb-01.jpg" alt="post-thumb">
                            </a>
                        <!-- Post Content -->
                        <div>
                            <div class="d-flex align-items-center border-bottom">
                                <!-- Published Date -->
                                <div class="text-center border-right p-4">
                                    <h3 class="text-primary mb-0">
                                        25
                                        <span class="d-block paragraph">Nov</span>
                                    </h3>
                                </div>
                                <div class="px-4">
                                    <!-- Post Title -->
                                    <a class="h4 d-block mb-10" href="/blog-single.html">Tips For Business Success 2017: Why To Online</a>
                                    <!-- Post Meta -->
                                    <ul class="list-inline">
                                        <li class="list-inline-item paragraph mr-5">By
                                            <a href="#" class="paragraph">Admin</a>
                                        </li>
                                        <li class="list-inline-item paragraph">Advice, Fitness</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Post Excerpts -->
                            <div class="p-4">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur 
    adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
    magna aliqua.
                                    Ut enim ad minim veniam, quis nostrud 
    exercitation ullamco laboris.
                                </p>
                                <a href="/blog-single.html" class="btn btn-sm btn-primary">Read More</a>
                            </div>
                        </div>
                    </article>
                    <!-- Blog Post with Slider -->
                    <article class="bg-white rounded mb-40">
                        <!-- Post Slider -->
                        <div class="post-slider slick-initialized slick-slider"><button type="button" class="prevArrow slick-arrow" style=""><i class="ti-arrow-left"></i></button>
                                <div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 5110px; transform: translate3d(-1460px, 0px, 0px);"><img class="img-fluid rounded-top slick-slide slick-cloned" src="blogs-Dateien/blog-big-thumb-01.jpg" alt="slider-thumb" data-slick-index="-1" aria-hidden="true" style="width: 730px;" tabindex="-1"><img class="img-fluid rounded-top slick-slide" src="blogs-Dateien/blog-big-thumb-02.jpg" alt="slider-thumb" data-slick-index="0" aria-hidden="true" style="width: 730px;" tabindex="-1"><img class="img-fluid rounded-top slick-slide slick-current slick-active" src="blogs-Dateien/blog-big-thumb-03.jpg" alt="slider-thumb" data-slick-index="1" aria-hidden="false" style="width: 730px;" tabindex="0"><img class="img-fluid rounded-top slick-slide" src="blogs-Dateien/blog-big-thumb-01.jpg" alt="slider-thumb" data-slick-index="2" aria-hidden="true" style="width: 730px;" tabindex="-1"><img class="img-fluid rounded-top slick-slide slick-cloned" src="blogs-Dateien/blog-big-thumb-02.jpg" alt="slider-thumb" data-slick-index="3" aria-hidden="true" style="width: 730px;" tabindex="-1"><img class="img-fluid rounded-top slick-slide slick-cloned" src="blogs-Dateien/blog-big-thumb-03.jpg" alt="slider-thumb" data-slick-index="4" aria-hidden="true" style="width: 730px;" tabindex="-1"><img class="img-fluid rounded-top slick-slide slick-cloned" src="blogs-Dateien/blog-big-thumb-01.jpg" alt="slider-thumb" data-slick-index="5" aria-hidden="true" style="width: 730px;" tabindex="-1"></div></div>
                                
                                
                        <button type="button" class="nextArrow slick-arrow" style=""><i class="ti-arrow-right"></i></button></div>
                        <!-- Post Content -->
                        <div>
                            <div class="d-flex align-items-center border-bottom">
                                <!-- Published Date -->
                                <div class="text-center border-right p-4">
                                    <h3 class="text-primary mb-0">
                                        25
                                        <span class="d-block paragraph">Nov</span>
                                    </h3>
                                </div>
                                <div class="px-4">
                                    <!-- Post Title -->
                                    <a class="h4 d-block mb-10" href="/blog-single.html">Tips For Business Success 2017: Why To Online</a>
                                    <!-- Post Meta -->
                                    <ul class="post-meta list-inline">
                                        <li class="list-inline-item paragraph mr-5">By
                                            <a class="paragraph" href="#">Admin</a>
                                        </li>
                                        <li class="list-inline-item paragraph">Advice, Fitness</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Post Excerpts -->
                            <div class="p-4">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur 
    adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
    magna aliqua.
                                    Ut enim ad minim veniam, quis nostrud 
    exercitation ullamco laboris.
                                </p>
                                <a href="/blog-single.html" class="btn btn-sm btn-primary">Read More</a>
                            </div>
                        </div>
                    </article>
                    <!-- Blog Post with Video -->
                    <article class="bg-white rounded mb-40">
                        <!-- Post Thumbnail -->
                        <div class="overlay overlay-rounded-top">
                            <img class="img-fluid w-100 rounded-top" src="blogs-Dateien/blog-big-thumb-03.jpg" alt="post-thumb">
                            <a class="popup-youtube play-icon centralized" href="https://www.youtube.com/watch?v=6ZfuNTqbHE8">
                                <i class="ti-control-play"></i>
                            </a>
                        </div>
                        <!-- Post Content -->
                        <div>
                            <div class="d-flex align-items-center border-bottom">
                                <!-- Published Date -->
                                <div class="text-center border-right p-4">
                                    <h3 class="text-primary mb-0">
                                        25
                                        <span class="d-block paragraph">Nov</span>
                                    </h3>
                                </div>
                                <div class="px-4">
                                    <!-- Post Title -->
                                    <a class="h4 d-block mb-10" href="/blog-single.html">Tips For Business Success 2017: Why To Online</a>
                                    <!-- Post Meta -->
                                    <ul class="list-inline">
                                        <li class="list-inline-item paragraph mr-5">By
                                            <a href="#" class="paragraph">Admin</a>
                                        </li>
                                        <li class="list-inline-item paragraph">Advice, Fitness</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Post Excerpts -->
                            <div class="p-4">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur 
    adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
    magna aliqua.
                                    Ut enim ad minim veniam, quis nostrud 
    exercitation ullamco laboris.
                                </p>
                                <a href="/blog-single.html" class="btn btn-sm btn-primary">Read More</a>
                            </div>
                        </div>
                    </article>
                    <!-- Blog Post Without Thumbnail -->
                    <article class="bg-white rounded mb-40">
                        <!-- Post Content -->
                        <div>
                            <div class="d-flex align-items-center border-bottom">
                                <!-- Published Date -->
                                <div class="text-center border-right p-4">
                                    <h3 class="text-primary mb-0">
                                        25
                                        <span class="d-block paragraph">Nov</span>
                                    </h3>
                                </div>
                                <div class="px-4">
                                    <!-- Post Title -->
                                    <a class="h4 d-block mb-10" href="/blog-single.html">Tips For Business Success 2017: Why To Online</a>
                                    <!-- Post Meta -->
                                    <ul class="list-inline">
                                        <li class="list-inline-item paragraph mr-5">By
                                            <a href="#" class="paragraph">Admin</a>
                                        </li>
                                        <li class="list-inline-item paragraph">Advice, Fitness</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Post Excerpts -->
                            <div class="p-4">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur 
    adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
    magna aliqua.
                                    Ut enim ad minim veniam, quis nostrud 
    exercitation ullamco laboris.
                                </p>
                                <a href="/blog-single.html" class="btn btn-sm btn-primary">Read More</a>
                            </div>
                        </div>
                    </article>
                    <!-- Pagination -->
                    <nav class="mb-md-50">
                        <ul class="pagination justify-content-center align-items-center">
                            <li class="page-item disabled prev">
                                <a class="page-link" href="#" tabindex="-1">Prev</a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link" href="#">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">2</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">3</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">4</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">5</a>
                            </li>
                            <li class="page-item next">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-4">
                    <!-- Sidebar -->
                    <div class="bg-white px-4 py-100 sidebar-box-shadow">
                        <!-- Search Widget -->
                        <div class="mb-50">
                            <h4 class="mb-3">Search Here</h4>
                            <div class="search-wrapper">
                                <input type="text" class="form-control" name="search" placeholder="Type Here...">
                            </div>
                        </div>
                        <!-- categories -->
                        <div class="mb-50">
                            <h4 class="mb-3">Categories</h4>
                            <ul class="pl-0 mb-0">
                                <li class="border-bottom">
                                    <a href="#" class="d-block text-color py-10">Business Analysis</a>
                                </li>
                                <li class="border-bottom">
                                    <a href="#" class="d-block text-color py-10">Consultancy</a>
                                </li>
                                <li class="border-bottom">
                                    <a href="#" class="d-block text-color py-10">Investment</a>
                                </li>
                                <li class="border-bottom">
                                    <a href="#" class="d-block text-color py-10">Profit &amp; Growth</a>
                                </li>
                                <li>
                                    <a href="#" class="d-block text-color py-10">Marketing Guidance</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Widget Recent Post -->
                        <div class="mb-50">
                            <h4 class="mb-3">Recent News</h4>
                            <div class="d-flex py-3 border-bottom">
                                <div class="mr-4">
                                    <a href="/blog-single.html">
                                        <img class="rounded" src="blogs-Dateien/post-thumb-sm-01.jpg" alt="post-thumb">
                                    </a>
                                </div>
                                <div>
                                    <h6 class="mb-3">
                                        <a class="text-dark" href="/blog-single.html">Marketing Strategy 2017-2018.</a>
                                    </h6>
                                    <p class="meta">16 Dec, 2018</p>
                                </div>
                            </div>
                            <div class="d-flex py-3 border-bottom">
                                <div class="mr-4">
                                    <a href="/blog-single.html">
                                        <img class="rounded" src="blogs-Dateien/post-thumb-sm-02.jpg" alt="post-thumb">
                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="mb-3">
                                        <a class="text-dark" href="/blog-single.html">Jack Ma &amp; future of E-commerce</a>
                                    </h6>
                                    <p class="meta">16 Dec, 2018</p>
                                </div>
                            </div>
                            <div class="d-flex py-3">
                                <div class="mr-4">
                                    <a href="/blog-single.html">
                                        <img class="rounded" src="blogs-Dateien/post-thumb-sm-03.jpg" alt="post-thumb">
                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="mb-3">
                                        <a class="text-dark" href="/blog-single.html">Jack Ma &amp; future of E-commerce</a>
                                    </h6>
                                    <p class="meta">16 Dec, 2018</p>
                                </div>
                            </div>
                        </div>
                        <!-- Widget Tags -->
                        <div class="mb-50">
                            <h4 class="mb-3">Tags</h4>
                            <ul class="list-inline tag-list">
                                <li class="list-inline-item">
                                    <a href="#">Business</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#">Marketing</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#">Finance</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#">Consultancy</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#">Market Analysis</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="#">Rvenenue</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Widget Newsletter -->
                        <div class="newsletter">
                            <h4 class="mb-3">Stay Updated</h4>
                            <form action="#">
                                <input type="text" name="name" id="name" class="form-control" placeholder="Name">
                                <input type="email" name="email" id="email" class="form-control" placeholder="Email">
                                <button type="submit" class="btn btn-primary btn-sm">Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- *** Blog Section End *** -->
  </div>
</template>

<script>

export default {

  components: {
  },

  setup() {
    return {};
  },
};
</script>

<style>
</style>
